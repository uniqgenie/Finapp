import React from "react";
import "./index.css";

export default function Main() {
  return (
    <div className="main-container">
      <div className="body">
        <div className="section">
          <div className="header">
            <div className="vector" />
            <div className="flex-row-fc">
              <div className="logo">
                <div className="vector-1" />
                <div className="vector-2" />
              </div>
              <span className="site-language-english">
                Site language: English
              </span>
              <div className="vector-3" />
              <div className="clip-path-group">
                <div className="group">
                  <div className="vector-4" />
                </div>
              </div>
              <div className="vector-5" />
              <div className="vector-6" />
              <div className="vector-7" />
              <div className="vector-8" />
              <div className="vector-9" />
            </div>
            <div className="vector-a" />
            <div className="flex-row-c">
              <div className="vector-b" />
              <div className="vector-c" />
              <div className="vector-d" />
            </div>
          </div>
          <div className="vector-e" />
          <div className="vector-f" />
          <div className="vector-10" />
          <div className="flex-row-dec">
            <div className="vector-11" />
            <div className="vector-12" />
          </div>
          <div className="flex-row-d">
            <div className="vector-13" />
            <div className="vector-14" />
          </div>
          <div className="vector-15" />
          <div className="vector-16" />
          <div className="vector-17" />
          <div className="vector-18" />
          <div className="vector-19" />
          <div className="flex-row">
            <div className="vector-1a" />
            <div className="vector-1b" />
          </div>
          <div className="vector-1c" />
          <div className="vector-1d" />
          <div className="vector-1e" />
          <div className="vector-1f" />
          <div className="vector-20" />
          <div className="vector-21" />
          <div className="vector-22" />
          <div className="vector-23" />
          <div className="vector-24" />
          <div className="vector-25" />
          <div className="vector-26" />
          <div className="vector-27" />
          <div className="vector-28" />
          <div className="vector-29" />
          <div className="vector-2a" />
          <div className="vector-2b" />
          <div className="vector-2c" />
          <div className="vector-2d" />
          <div className="vector-2e" />
          <div className="vector-2f" />
          <div className="vector-30" />
          <div className="vector-31" />
          <div className="flex-row-a">
            <div className="affbedfcd-svg">
              <div className="flex-column-ec">
                <div className="vector-32" />
                <div className="vector-33" />
              </div>
              <div className="vector-34" />
              <div className="vector-35" />
              <div className="vector-36" />
              <div className="vector-37" />
              <div className="vector-38" />
              <div className="vector-39" />
              <div className="vector-3a" />
              <div className="vector-3b" />
              <div className="vector-3c" />
              <div className="vector-3d" />
              <div className="vector-3e" />
              <div className="vector-3f" />
              <div className="vector-40" />
              <div className="vector-41" />
              <div className="vector-42" />
              <div className="vector-43" />
              <div className="vector-44" />
              <div className="vector-45" />
              <div className="vector-46" />
              <div className="vector-47" />
              <div className="vector-48" />
              <div className="vector-49" />
              <div className="vector-4a" />
              <div className="vector-4b" />
              <div className="vector-4c" />
              <div className="vector-4d" />
              <div className="vector-4e" />
              <div className="vector-4f" />
              <div className="vector-50" />
            </div>
            <div className="vector-51" />
            <div className="vector-52" />
            <div className="vector-53" />
            <div className="vector-54" />
            <div className="vector-55" />
            <div className="vector-56" />
            <div className="vector-57" />
            <div className="vector-58" />
            <div className="vector-59" />
            <span className="the-free-way">
              The free, fun, and effective way to learn a language!
            </span>
            <div className="vector-5a" />
            <div className="vector-5b" />
            <div className="vector-5c" />
            <div className="vector-5d" />
            <div className="vector-5e" />
            <div className="vector-5f" />
            <div className="vector-60" />
            <div className="vector-61" />
            <div className="vector-62" />
            <div className="vector-63" />
            <div className="vector-64" />
            <div className="vector-65" />
            <div className="vector-66" />
            <div className="vector-67" />
            <div className="vector-68" />
            <div className="vector-69" />
            <div className="vector-6a" />
            <div className="vector-6b" />
            <div className="vector-6c" />
            <div className="vector-6d" />
            <div className="vector-6e" />
            <div className="vector-6f" />
            <div className="vector-70" />
            <div className="a">
              <button className="a-before" />
              <span className="get-started">Get started</span>
            </div>
            <div className="vector-71" />
            <div className="vector-72" />
            <div className="vector-73" />
            <div className="vector-74" />
            <div className="vector-75" />
            <div className="vector-76" />
            <div className="vector-77" />
            <div className="vector-78" />
            <div className="vector-79" />
            <div className="vector-7a" />
            <div className="vector-7b" />
            <div className="vector-7c" />
            <div className="vector-7d" />
            <div className="vector-7e" />
            <div className="vector-7f" />
            <div className="vector-80" />
            <div className="button">
              <button className="button-before" />
              <span className="already-have-account">
                I ALREADY HAVE AN ACCOUNT
              </span>
            </div>
            <div className="vector-81" />
            <div className="vector-82" />
            <div className="vector-83" />
            <div className="vector-84" />
            <div className="vector-85" />
            <div className="vector-86" />
            <div className="vector-87" />
            <div className="vector-88" />
            <div className="vector-89" />
            <div className="vector-8a" />
            <div className="vector-8b" />
            <div className="vector-8c" />
            <div className="vector-8d" />
            <div className="vector-8e" />
            <div className="vector-8f" />
            <div className="vector-90" />
            <div className="vector-91" />
            <div className="vector-92" />
            <div className="vector-93" />
            <div className="vector-94" />
            <div className="vector-95" />
            <div className="vector-96" />
            <div className="vector-97" />
            <div className="vector-98" />
          </div>
          <div className="vector-99" />
          <div className="flex-row-d-9a">
            <div className="vector-9b" />
            <div className="vector-9c" />
          </div>
          <div className="vector-9d" />
          <div className="vector-9e" />
          <div className="vector-9f" />
          <div className="vector-a0" />
          <div className="vector-a1" />
          <div className="vector-a2" />
          <div className="vector-a3" />
          <div className="vector-a4" />
          <div className="flex-row-a-a5">
            <div className="vector-a6" />
            <div className="vector-a7" />
          </div>
          <div className="vector-a8" />
          <div className="vector-a9" />
          <div className="vector-aa" />
          <div className="vector-ab" />
          <div className="flex-row-cd">
            <div className="vector-ac" />
            <div className="vector-ad" />
          </div>
          <div className="vector-ae" />
          <div className="vector-af" />
          <div className="vector-b0" />
          <div className="vector-b1" />
          <div className="vector-b2" />
          <div className="vector-b3" />
          <div className="vector-b4" />
          <div className="vector-b5" />
          <div className="flex-row-c-b6">
            <div className="vector-b7" />
            <div className="vector-b8" />
          </div>
          <div className="vector-b9" />
          <div className="vector-ba" />
          <div className="vector-bb" />
          <div className="vector-bc" />
          <div className="vector-bd" />
          <div className="vector-be" />
          <div className="vector-bf" />
          <div className="vector-c0" />
          <div className="language-nav">
            <div className="languages">
              <div className="ul">
                <div className="a-c1">
                  <div className="svg">
                    <div className="frame" />
                  </div>
                  <span className="spanish">Spanish</span>
                </div>
                <div className="a-c2">
                  <div className="svg-c3">
                    <div className="frame-c4" />
                  </div>
                  <span className="french">French</span>
                </div>
                <div className="a-c5">
                  <div className="svg-c6">
                    <div className="frame-c7" />
                  </div>
                  <span className="german">German</span>
                </div>
                <div className="a-c8">
                  <div className="svg-c9">
                    <div className="frame-ca" />
                  </div>
                  <span className="italian">Italian</span>
                </div>
                <div className="a-cb">
                  <div className="svg-cc">
                    <div className="frame-cd" />
                  </div>
                  <span className="portuguese">Portuguese</span>
                </div>
                <div className="a-ce">
                  <div className="svg-cf">
                    <div className="frame-d0" />
                  </div>
                  <span className="dutch">Dutch</span>
                </div>
                <div className="a-d1">
                  <div className="svg-d2">
                    <div className="frame-d3" />
                  </div>
                  <span className="japanese">Japanese</span>
                </div>
              </div>
            </div>
            <div className="chevron-left">
              <div className="frame-d4">
                <div className="vector-d5" />
              </div>
            </div>
            <div className="chevron-right">
              <div className="frame-d6">
                <div className="vector-d7" />
              </div>
            </div>
          </div>
        </div>
        <div className="section-d8">
          <div className="div">
            <div className="div-d9">
              <div className="effdddfdb-svg">
                <div className="feet">
                  <div className="left-foot" />
                  <div className="right-foot" />
                </div>
                <div className="torso" />
                <div className="face" />
                <div className="wings">
                  <div className="right-wing" />
                  <div className="left-wing" />
                </div>
                <div className="belly" />
              </div>
            </div>
            <div className="div-da">
              <span className="the-worlds-1-way">
                The world’s #1 way to learn a language
              </span>
              <div className="learning-with-duolingo">
                <span className="learning-with-duolingo-is-fun">
                  Learning with Duolingo is fun, and
                </span>
                <span className="research-shows-that-it-works">
                  research shows that it works
                </span>
                <span className="learning-with-duolingo-is-fun-db">
                  ! With quick, bite-sized lessons, you’ll earn points and
                  unlock new levels while gaining real-world communication
                  skills.
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="div-dc" />
        <div className="section-dd">
          <div className="div-de">
            <span className="why-youll-love-learning-with-duolingo">
              Why you’ll love learning with Duolingo
            </span>
            <div className="div-df">
              <div className="div-e0">
                <div className="div-e1">
                  <div className="div-e2">
                    <div className="svg-e3">
                      <div className="group-e4">
                        <div className="group-e5" />
                      </div>
                    </div>
                  </div>
                  <div className="div-e6">
                    <span className="effective-and-efficient">
                      Effective and efficient
                    </span>
                    <div className="our-courses-teach-skills">
                      <span className="check-out-our-latest-research">
                        Our courses effectively and efficiently teach reading,
                        listening, and speaking skills. Check out our
                      </span>
                      <span className="latest-research">latest research</span>
                      <span className="exclamation">!</span>
                    </div>
                  </div>
                </div>
                <div className="div-e7">
                  <div className="div-e8">
                    <div className="svg-e9">
                      <div className="group-ea">
                        <div className="group-eb" />
                      </div>
                    </div>
                  </div>
                  <div className="div-ec">
                    <span className="personalized-learning">
                      Personalized learning
                    </span>
                    <span className="lessons-tailored-to-help">
                      Combining the best of AI and language science, lessons are
                      tailored to help you learn at just the right level and
                      pace.
                    </span>
                  </div>
                </div>
              </div>
              <div className="div-ed">
                <div className="ddfdefdbbfdb-svg">
                  <div className="group-ee">
                    <div className="group-ef">
                      <div className="group-f0">
                        <div className="vector-f1" />
                        <div className="vector-f2" />
                        <div className="group-f3">
                          <div className="group-f4">
                            <div className="vector-f5" />
                            <div className="vector-f6" />
                            <div className="vector-f7" />
                            <div className="vector-f8" />
                            <div className="group-f9">
                              <div className="group-fa" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="vector-fb" />
                      <div className="vector-fc" />
                      <div className="vector-fd" />
                    </div>
                  </div>
                </div>
              </div>
              <div className="div-fe">
                <div className="div-ff">
                  <div className="div-100">
                    <div className="svg-101">
                      <div className="crown" />
                    </div>
                  </div>
                  <div className="div-102">
                    <span className="span">Stay motivated</span>
                    <span className="stay-motivated">
                      We make it easy to form a habit of language learning, with
                      game-like features, fun challenges, and reminders from our
                      friendly mascot, Duo the owl.
                    </span>
                  </div>
                </div>
                <div className="div-103">
                  <div className="div-104">
                    <div className="svg-105">
                      <div className="profile-active">
                        <div className="active" />
                      </div>
                    </div>
                  </div>
                  <div className="div-106">
                    <span className="have-fun-with-it">Have fun with it!</span>
                    <span className="effective-learning">
                      Effective learning doesn’t have to be boring! Build your
                      skills each day with engaging exercises and playful
                      characters.
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="div-107" />
        <div className="section-108">
          <div className="div-109">
            <div className="svg-10a">
              <div className="svg-10b">
                <div className="flex-column">
                  <div className="vector-10c" />
                  <div className="vector-10d" />
                  <div className="vector-10e" />
                  <div className="vector-10f" />
                  <div className="vector-110" />
                  <div className="vector-111" />
                  <div className="vector-112" />
                  <div className="vector-113" />
                  <div className="vector-114" />
                  <div className="vector-115" />
                  <div className="vector-116" />
                  <div className="vector-117" />
                  <div className="vector-118" />
                  <div className="vector-119" />
                  <div className="group-11a">
                    <div className="vector-11b" />
                  </div>
                  <div className="group-11c">
                    <div className="vector-11d" />
                  </div>
                  <div className="vector-11e" />
                  <div className="group-11f">
                    <div className="vector-120" />
                  </div>
                  <div className="vector-121" />
                  <div className="vector-122" />
                </div>
                <div className="vector-123" />
                <div className="vector-124" />
              </div>
            </div>
            <div className="div-125">
              <span className="boost-your-learning">
                Boost your learning with Super Duolingo
              </span>
              <span className="learn-more-about-super">
                Learning a language on Duolingo is completely free, but you can
                remove ads and support free education with Super. First 2 weeks
                on us!
              </span>
              <span className="learn-more-about-super-duolingo">
                Learn more about Super Duolingo
              </span>
            </div>
          </div>
        </div>
        <div className="div-126" />
        <div className="section-127">
          <div className="div-128">
            <div className="div-129">
              <span className="learn-anytime-anywhere">
                Learn anytime, anywhere.
              </span>
              <span className="make-your-breaks">
                Make your breaks and commutes more productive with our iPhone
                and Android apps. Download them and see why Apple and Google
                gave us their highest accolades.
              </span>
              <div className="div-12a">
                <div className="a-12b">
                  <button className="a-before-12c" />
                  <div className="svg-12d">
                    <div className="frame-12e">
                      <div className="vector-12f" />
                      <div className="vector-130" />
                    </div>
                  </div>
                  <div className="span-131">
                    <span className="download-on-the">Download on the</span>
                    <span className="app-store">App Store</span>
                  </div>
                </div>
                <div className="a-132">
                  <button className="a-before-133" />
                  <div className="svg-134">
                    <div className="frame-135">
                      <div className="vector-136" />
                    </div>
                  </div>
                  <div className="span-137">
                    <span className="get-it-on">Get it on</span>
                    <span className="google-play">Google Play</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="div-138">
              <div className="bbcefadced-svg">
                <div className="group-139">
                  <div className="group-13a">
                    <div className="group-13b">
                      <div className="group-13c" />
                      <div className="vector-13d" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="div-13e" />
        <div className="section-13f">
          <div className="div-140">
            <div className="div-141">
              <div className="svg-142">
                <div className="group-143">
                  <div className="group-144">
                    <div className="vector-145" />
                    <div className="vector-146" />
                    <div className="vector-147" />
                    <div className="vector-148" />
                    <div className="group-149">
                      <div className="group-14a" />
                      <div className="group-14b" />
                      <div className="group-14c" />
                    </div>
                    <div className="group-14d" />
                    <div className="group-14e" />
                    <div className="group-14f" />
                    <div className="group-150" />
                    <div className="group-151" />
                    <div className="group-152" />
                  </div>
                </div>
              </div>
            </div>
            <div className="div-153">
              <span className="duolingo-for-schools">Duolingo for Schools</span>
              <span className="free-teacher-tools">
                Free teacher tools to help students learn languages through the
                Duolingo app, both in and out of the classroom.
              </span>
              <span className="bring-duolingo-to-classroom">
                Bring Duolingo to your classroom
              </span>
            </div>
          </div>
        </div>
        <div className="div-154" />
        <div className="section-155">
          <div className="div-156">
            <div className="div-157">
              <span className="the-duolingo-english-test">
                The Duolingo English Test
              </span>
              <span className="welcome-to-the-test">
                Welcome to the convenient, fast, and affordable English test
                accepted around the world. By integrating the latest assessment
                science and AI, we empower anyone to take the test where and
                when they’re at their best.
              </span>
              <span className="certify-your-english">CERTIFY YOUR ENGLISH</span>
            </div>
            <div className="div-158">
              <div className="svg-159">
                <div className="page">
                  <div className="img-duo-shield">
                    <div className="group-15a" />
                    <div className="fill" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="div-15b" />
        <div className="section-15c">
          <div className="div-15d">
            <div className="div-15e">
              <div className="svg-15f">
                <div className="vector-160" />
                <div className="flex-row-d-161">
                  <div className="mask-group" />
                  <div className="vector-162" />
                  <div className="vector-163" />
                  <div className="vector-164" />
                  <div className="vector-165" />
                  <div className="vector-166" />
                  <div className="vector-167" />
                  <div className="vector-168" />
                  <div className="vector-169" />
                  <div className="vector-16a" />
                  <div className="vector-16b" />
                  <div className="vector-16c" />
                  <div className="vector-16d" />
                  <div className="vector-16e" />
                  <div className="vector-16f" />
                  <div className="vector-170" />
                  <div className="vector-171" />
                  <div className="vector-172" />
                  <div className="vector-173" />
                  <div className="vector-174" />
                  <div className="vector-175" />
                  <div className="vector-176" />
                  <div className="vector-177" />
                  <div className="vector-178" />
                  <div className="vector-179" />
                  <div className="vector-17a" />
                  <div className="vector-17b" />
                  <div className="vector-17c" />
                  <div className="vector-17d" />
                  <div className="vector-17e" />
                  <div className="vector-17f" />
                  <div className="vector-180" />
                  <div className="vector-181" />
                  <div className="vector-182" />
                </div>
                <div className="vector-183" />
                <div className="vector-184" />
                <div className="vector-185" />
                <div className="mask-group-186">
                  <div className="group-187">
                    <div className="vector-188" />
                    <div className="vector-189" />
                    <div className="vector-18a" />
                  </div>
                </div>
                <div className="flex-row-18b">
                  <div className="vector-18c" />
                  <div className="vector-18d" />
                  <div className="vector-18e" />
                </div>
                <div className="vector-18f" />
              </div>
            </div>
            <div className="div-190">
              <span className="effective-and-efficient-courses">
                Effective and efficient courses
              </span>
              <span className="our-courses-teach-skills-191">
                Our courses effectively and efficiently teach reading,
                listening, and speaking skills. Check out our latest research!
              </span>
              <span className="learn-more-research">
                Learn more about our research
              </span>
            </div>
          </div>
        </div>
        <div className="footer">
          <div className="site-columns">
            <div className="about-us">
              <span className="about-us-192">About us</span>
              <div className="ul-193">
                <span className="courses">Courses</span>
                <span className="mission">Mission</span>
                <span className="approach">Approach</span>
                <span className="efficacy">Efficacy</span>
                <span className="team">Team</span>
                <span className="research">Research</span>
                <span className="careers">Careers</span>
                <span className="brand-guidelines">Brand guidelines</span>
                <span className="store">Store</span>
                <span className="press">Press</span>
                <span className="investors">Investors</span>
                <span className="contact-us">Contact us</span>
              </div>
            </div>
            <div className="products">
              <span className="products-194">Products</span>
              <div className="products-195">
                <span className="duolingo">Duolingo</span>
                <span className="duolingo-for-schools-196">
                  Duolingo for Schools
                </span>
                <span className="duolingo-english-test">
                  Duolingo English Test
                </span>
                <span className="duolingo-abc">Duolingo ABC</span>
                <span className="duolingo-math">Duolingo Math</span>
                <span className="podcast">Podcast</span>
                <span className="stories">Stories</span>
                <span className="duolingo-for-business">
                  Duolingo for Business
                </span>
                <span className="super-duolingo">Super Duolingo</span>
                <span className="gift-super-duolingo">Gift Super Duolingo</span>
              </div>
            </div>
            <div className="apps">
              <span className="apps-197">Apps</span>
              <div className="apps-198">
                <span className="duolingo-for-android">
                  Duolingo for Android
                </span>
                <span className="duolingo-for-ios">Duolingo for iOS</span>
                <span className="duolingo-abc-ios">Duolingo ABC (iOS)</span>
              </div>
            </div>
            <div className="help-and-support">
              <span className="help-and-support-199">Help and support</span>
              <div className="help-and-support-19a">
                <span className="duolingo-faqs">Duolingo FAQs</span>
                <span className="schools-faqs">Schools FAQs</span>
                <span className="duolingo-english-test-faqs">
                  Duolingo English Test FAQs
                </span>
                <span className="status">Status</span>
              </div>
            </div>
            <div className="privacy-and-terms">
              <span className="privacy-and-terms-19b">Privacy and terms</span>
              <div className="privacy-and-terms-19c">
                <span className="community-guidelines">
                  Community guidelines
                </span>
                <span className="terms">Terms</span>
                <span className="privacy">Privacy</span>
                <span className="respecting-your-do-not-sell-my-personal-information-rights">
                  Respecting your "do not sell my personal information" rights
                </span>
              </div>
              <span className="social">Social</span>
              <div className="social-19d">
                <span className="blog">Blog</span>
                <span className="instagram">Instagram</span>
                <span className="social-media">Facebook</span>
                <span className="social-media-19e">Twitter</span>
                <span className="social-media-19f">YouTube</span>
              </div>
            </div>
          </div>
          <span className="site-language">Site language:</span>
          <div className="flex-row-a-1a0">
            <span className="arabic">العربية</span>
            <span className="bengali">বাংলা</span>
            <span className="czech">Čeština</span>
            <span className="german-1a1">Deutsch</span>
            <span className="greek">Ελληνικά</span>
            <span className="english">English</span>
            <span className="spanish-1a2">Español</span>
            <span className="french-1a3">Français</span>
            <span className="hindi">हिंदी</span>
            <span className="hungarian">Magyar</span>
            <span className="indonesian">Bahasa Indonesia</span>
            <span className="italian-1a4">Italiano</span>
            <span className="japanese-1a5">日本語</span>
            <span className="korean">한국어</span>
          </div>
          <div className="flex-row-afb">
            <span className="dutch-1a6">Nederlands</span>
            <span className="polish">Polski</span>
            <span className="portuguese-1a7">Português</span>
            <span className="romanian">Română</span>
            <span className="russian">Русский</span>
            <span className="thai">ภาษาไทย</span>
            <span className="tagalog">Tagalog</span>
            <span className="turkish">Türkçe</span>
            <span className="ukrainian">Українською</span>
            <span className="vietnamese">Tiếng Việt</span>
            <span className="chinese">中文</span>
          </div>
        </div>
      </div>
      <div className="footer-background">
        <div className="group-1a8" />
        <div className="a-1a9">
          <button className="button-1aa" />
          <span className="get-started-1ab">Get started</span>
        </div>
        <span className="learn-language">Learn a language with Duolingo.</span>
      </div>
    </div>
  );
}
